import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  AfterRemove,
  BeforeRemove,
} from 'typeorm';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column()
  email: string;

  @Column()
  gender: string;

  @Column()
  password: string;
  Order: any;

  @BeforeRemove()
  beforelogRemove() {
    console.log('before Removed this User', this.id);
  }

  @AfterRemove()
  logRemove() {
    console.log('Removed this User', this.id);
  }
}
