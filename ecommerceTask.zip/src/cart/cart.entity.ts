import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';
@Entity()
export class CartEntity {
  @PrimaryGeneratedColumn()
  id: number;
  @Column()
  product_id: number;
  @Column()
  user_id: number;
  @Column()
  amount: GLfloat;
}
