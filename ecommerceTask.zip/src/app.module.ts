import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { User } from './user/user.entity';
import { UserModule } from './user/user.module';
import { MailerModule } from '@nestjs-modules/mailer';
import { CartModule } from './cart/cart.module';
import { CartEntity } from './cart/cart.entity';
import { OrderModule } from './order/order.module';
import { OrderEntity } from './order/order.entity';
import { AuthModule } from './auth/auth.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'sqlite',
      database: 'db.sqlite',
      entities: [User, CartEntity, OrderEntity],
      synchronize: true,
    }),
    MailerModule.forRoot({
      transport: {
        host: 'smtp.sendgrid.net',
        auth: {
          user: 'apikey',
          password:
            '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',
        },
      },
    }),
    UserModule,
    MailerModule,
    CartModule,
    OrderModule,
    AuthModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
