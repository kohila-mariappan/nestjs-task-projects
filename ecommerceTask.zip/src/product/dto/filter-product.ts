export class FilterProductDTO {
  search: string;
  category: string;
}
